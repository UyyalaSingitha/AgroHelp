from django.shortcuts import render
from Regapp.models import Register

from Regapp.forms import RegisterForm
from django.shortcuts import redirect
# Create your views here.
def form_view(request):
    form=RegisterForm()
    if request.method=="POST":
        form=RegisterForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('/')

    return render(request,'Register.html',{'form':form })
