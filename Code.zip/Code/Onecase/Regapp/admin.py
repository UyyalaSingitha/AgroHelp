from django.contrib import admin
from Regapp.models import Register
# Register your models here.
class RegisterAdmin(admin.ModelAdmin):
    list_display=['firstname','lastname','username','email']
admin.site.register(Register,RegisterAdmin)