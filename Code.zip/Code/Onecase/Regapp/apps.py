from django.apps import AppConfig


class RegappConfig(AppConfig):
    name = 'Regapp'
