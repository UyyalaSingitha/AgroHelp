from django.shortcuts import render,HttpResponse,redirect
from datetime import datetime
from Home.models import Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.models import User
from django.contrib.auth import logout,authenticate,login
#from django.contrib.auth.models import User
#from django.contrib.auth import login,authenticate

# Create your views here.
def index(request):
    if request.user.is_anonymous:
        return redirect('/signin')
    context={
        "variable":'this is sent'
    }
    #return HttpResponse('This is Home Page')
    return render(request,'index.html',context)

def about(request):
    # return HttpResponse('This is about Page')
    return render(request,'about.html')


def contact(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact=Contact(name=name,email=email,phone=phone,desc=desc,date=datetime.today())
        contact.save()
        messages.success(request,'Your message has been sent!')
    #return HttpResponse('This is Contact Page')
    return render(request,'contact.html')
def loginUser(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(username,password)
        user=authenticate(username=username,password=password)
        print('user is',user)
        if user is not  None:
            login(request,user)
            return redirect('/needs')
        else:
            return render(request,'login.html')
    return render(request,'login.html')
def logoutUser(request):
    logout(request)
    return redirect('/signin')
def needs(request):
    return render(request,'needs.html')
def payment(request):
    return render(request,'payment.html')

def seeds(request):
    return render(request,'seeds.html')

def fertilisers(request):
    return render(request,'fertilisers.html')

def suggestions(request):
    return render(request,'suggestions.html')
def mult(request):
    if request.method=="POST":
        v=request.POST['n']
        p=request.POST['s']
        if int(p) in [500,300,400,600,1000,700]:
            res=int(v)*int(p)
            return render(request,'result.html',{'result':res})
    return HttpResponse('please go back and enter the valid cost as provided')
def confirm(request):
    return render(request,'confirm.html')

def yes(request):
    return render(request,'yes.html')