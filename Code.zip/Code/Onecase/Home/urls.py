from django.urls import path
from Home import views
urlpatterns = [
    path('',views.index,name='Home'),
    path('about',views.about,name='about'),
    path('contact',views.contact,name='contact'),
    path('signin',views.loginUser,name='signin'),
    path('logout',views.logoutUser,name="logout"),
    path('needs',views.needs,name='needs'),
    path('payment',views.payment,name='payment'),
    path('seeds',views.seeds,name='seeds'),
    path('fertilisers',views.fertilisers,name='fertilisers'),
    path('suggestions',views.suggestions,name='suggestions'),
    path('mult',views.mult,name='mult'),
    path('confirm',views.confirm,name='confirm'),
    path('yes',views.yes,name='yes')
]